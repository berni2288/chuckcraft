package appeng.api.me.tiles;

public interface ITileCable {

	public boolean coveredConnections();
	
}
